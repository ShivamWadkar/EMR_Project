package com.emr.controllers;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import javax.print.Doc;
import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialBlob;
import javax.xml.bind.attachment.AttachmentMarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.emr.message.*;
import com.emr.dao.DocumentDao;
import com.emr.dao.PatientDao;
import com.emr.pojo.Document;
import com.emr.pojo.Patient;
import com.emr.repositories.MyPatientRepository;

@Controller
public class DocumentController {

	@Autowired
	DocumentDao dao;

	@Autowired
	PatientDao pdao;

	@Autowired
	MyPatientRepository prepo;



	/*
	 * @GetMapping("/getDocumentByPatient/{id}") public void
	 * getDocumentById(@PathVariable("id") int id) { List<Document> list =
	 * dao.getDocumentById(id);
	 * 
	 * list.forEach(e->{ System.out.println(e); }); }
	 */

	@PostMapping("/add_document")
	public String addDocument(HttpServletRequest request, @RequestParam String documentType,@RequestParam String documentDate,@RequestParam String description,@RequestParam("file") MultipartFile file){

		String patientId = (String)request.getSession().getAttribute("uname");
		//pdao.getUserByUserId(patientId);

		Patient patient = prepo.findByLoginId(patientId);
		//System.out.println(request.getSession().getAttribute("id"));
		byte[] byteArr;
		Blob blob;
		try {
			byteArr = file.getBytes();
			blob = new SerialBlob(byteArr);
			dao.addDocument(patient,documentType,documentDate,description,blob);

			return "patientLogin";
		} catch (SQLException e) {

			e.printStackTrace();
			return "patientSignup";
		}
		catch (IOException e1) {

			e1.printStackTrace();
			return "patientSignup";
		}
	}

	/* @GetMapping("/files")
	  public ResponseEntity<List<ResponseFile>> getListFiles() {
	    List<ResponseFile> files = storageService.getAllFiles().map(dbFile -> {
	      String fileDownloadUri = ServletUriComponentsBuilder
	          .fromCurrentContextPath()
	          .path("/files/")
	          .path(dbFile.getId())
	          .toUriString();

	      return new ResponseFile(
	          dbFile.getName(),
	          fileDownloadUri,
	          dbFile.getType(),
	          dbFile.getData().length);
	    }).collect(Collectors.toList());

	    return ResponseEntity.status(HttpStatus.OK).body(files);
	  }
	 */




	@GetMapping("/getall") 
	public ResponseEntity<List<ResponseFile>>  getAllDcouments(HttpServletRequest req) 
	{ 
		String patientId =(String)req.getSession().getAttribute("uname");

		Patient patient = prepo.findByLoginId(patientId);
		//String docId =  String.valueOf(patient.getId());

		List<ResponseFile> files = dao.getAllDocuments(patient.getId()).map(doc ->{

			String fileDownloadUrl = ServletUriComponentsBuilder
					.fromCurrentContextPath()
					.path("/getall/")
					.path(String.valueOf(doc.getId()))
					.toUriString();

			return new ResponseFile(doc.getDocumentDescription(), fileDownloadUrl,doc.getDocumentType(), doc.getId());

		}).collect(Collectors.toList());

		return ResponseEntity.status(HttpStatus.OK).body(files); 
	}

	@GetMapping("/getall/{id}") 
	public ResponseEntity<Blob> getFile(@PathVariable String id) {

		System.out.println(id);
		int docId = Integer.parseInt(id);  
		Document d = dao.getdoc(docId); 


		return ResponseEntity.ok() .header(HttpHeaders.CONTENT_DISPOSITION,
				"attachment; filename=\"" + d.getDocumentType() + "\"")
				.body(d.getDocument()); 
	} 
}




/*
 * @GetMapping("/getall") public ResponseEntity<List<Document>>
 * getAllDcouments(HttpServletRequest req) { String patientId =
 * (String)req.getSession().getAttribute("uname");
 * 
 * Patient patient = prepo.findByLoginId(patientId);
 * 
 * List<Document> files = dao.getAllDocuments(patient.getId()).map(doc ->{
 * String fileDownloadUrl = ServletUriComponentsBuilder
 * .fromCurrentContextPath() .path("/getall/")
 * .path(doc.getDocumentDescription()) .toUriString();
 * 
 * return new
 * Document(doc.getId(),doc.getDocumentType(),doc.getDocumentDescription(),doc.
 * getDocument(),doc.getDocumentDate(),doc.getPatient());
 * 
 * }).collect(Collectors.toList());
 * 
 * //return ResponseEntity.status(HttpStatus.OK).body(); return
 * ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
 * "attachment; ").body(files);
 * 
 * } }
 */
