import React, { Component } from 'react';
import { Switch, Route, Link } from 'react-router-dom'

class Navigation extends Component {
  constructor(props){
    super(props)
    this.state={
      username:null
    }

  }
  componentDidMount(){
    if(sessionStorage.getItem('user')!= undefined)
    this.setState({
      username:JSON.parse(sessionStorage.getItem('user'))
    }) 
  }


  logout() {
    sessionStorage.removeItem('user')
    window.location = '/'
  }
  render() {
    
   
    // console.log(username.id);
    return (
      
      <div>
         <header className="top-header">
  <nav className="navbar header-nav navbar-expand-lg">
    <div className="container">
      <a className="navbar-brand" href="index.html"><img src="logo6.png" height="60px" alt="image" /></a>
      <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
        <span /> <span /> <span />
      </button>
      <div className="collapse navbar-collapse justify-content-end" id="navbar-wd">
        <ul className="navbar-nav">
          <li><a className="nav-link active" href="http://www.localhost:8080/index">Home</a></li>
          
        </ul>
      </div>
    </div>
  </nav>
</header>


      </div>
    );
  }
}

export default Navigation;