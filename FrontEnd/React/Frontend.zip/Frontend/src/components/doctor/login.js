import React, { Component } from 'react'
import Form from 'react-validation/build/form'
import Input from 'react-validation/build/input'
import CheckButton from 'react-validation/build/button'
import AuthService from '../service/AuthService'
import '../../css/home.css'

const required = (value) => {
  if (!value) {
    return (
      <div className="alert alert-danger" role="alert">
        This field is required!
      </div>
    )
  }
}

export default class Login extends Component {
  
  constructor(props) {
    super(props)
    this.handleLogin = this.handleLogin.bind(this)
    this.onChangeUsername = this.onChangeUsername.bind(this)
    this.onChangePassword = this.onChangePassword.bind(this)

    this.state = {
      email: '',
      password: '',
      loading: false,
      message: '',
    }
  }

  onChangeUsername(e) {
    this.setState({
      email: e.target.value,
    })
  }

  onChangePassword(e) {
    this.setState({
      password: e.target.value,
    })
  }
  
  handleLogin(e) {
    e.preventDefault()

    this.setState({
      message: '',
      loading: true,
    })

    this.form.validateAll()

    if (this.checkBtn.context._errors.length === 0) {
      AuthService.login(this.state.email, this.state.password).then(
        () => {
          window.location = '/Allservices'
        },
        (error) => {
          this.setState({
            loading: false,
            message: 'Invalid Login Details',
          })
        }
      )
    } else {
      this.setState({
        loading: false,
      })
    }
  }

  render() {
    return (
      <div>
        <div className="container-login100">
  <div className="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
    <form action="verify_doctor" method="post" className="login100-form validate-form">
      <span className="login100-form-title p-b-37">
        Doctor's Login
      </span>
      <div className="wrap-input100 validate-input m-b-20" data-validate="Enter username or email">
        <input className="input100" type="text" name="uname" placeholder="username or email" />
        <span className="focus-input100" />
      </div>
      <br/>
    
      <div className="wrap-input100 validate-input m-b-25" data-validate="Enter password">
        <input className="input100" type="password" name="pass" placeholder="password" />
        <span className="focus-input100" />
      </div>
      <br/>
      <div className="container-login100-form-btn">
        <button className="login100-form-btn">
          Sign In
        </button>
        
      </div>
      <br/>
      <div className="text-center">
        <a href="http://www.localhost:8080/doctor_signup" className="txt2 hov1">
          Sign Up
        </a>
      </div>
    </form>
  </div>

  

</div>

      </div>
    )
  }
}