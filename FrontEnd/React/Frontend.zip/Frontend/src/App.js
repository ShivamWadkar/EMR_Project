import './App.css'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import Login from './components/doctor/login'
import Navigation from './components/Navigation'
import React from 'react'
import logout from './components/logout'
import * as ReactBootStrap from "react-bootstrap"
import Profile from './components/doctor/Profile'

function App() {
  return (
    <div>
  
      <div>
     
        <Router>
        <Navigation></Navigation>
          <Switch>

            <Route path="/login"><Login></Login></Route>

            <Route path="/logout"><logout></logout></Route>
          
            <Route path="/customer/:id" component={Profile}></Route>
          
          </Switch>
        </Router>
      </div>
    
    </div>
  )
}


export default App
