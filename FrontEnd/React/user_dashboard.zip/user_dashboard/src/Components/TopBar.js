import React, { Component } from 'react'

export default class 
 extends Component {
  render() {
    return (
      <div>
          <nav className="navbar clearHeader">
  <div className="col-12">
    <div className="navbar-header">
      <a href="javascript:void(0);" className="bars" />
     
    </div>
    <ul className="nav navbar-nav navbar-right">
     
      <li><a href="javascript:void(0);" className="js-right-sidebar" data-close="true"><i className="zmdi zmdi-settings" /></a></li>
      <li><a href="/index.php/user/login/logout" title="Log out"><i className="zmdi zmdi-sign-in" /></a></li>
    </ul>
  </div>
</nav>

      </div>
    )
  }
}
