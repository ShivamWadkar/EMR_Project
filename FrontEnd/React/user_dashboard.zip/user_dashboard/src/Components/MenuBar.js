import React, { Component } from 'react'
export default class 
 extends Component {
  render() {
    return (
      <div>
        <section>
    
  {/* Left Sidebar */}
  <aside id="leftsidebar" className="sidebar">
    {/* User Info */}
    <div className="user-info">
      <div className="admin-image">
        <img src="https://lh3.googleusercontent.com/a-/AOh14GgiStWDNdN8FJC7mMn0aGuG-r1OhJIhwrMBlRveAA=s96-c" style={{height: 73, width: 73}} alt="avatar" />
      </div>
      <div className="admin-action-info">
        <span>Welcome</span>
        <h3>Shivam Wadkar</h3>
        <ul>
          <li><a href="/user/profile" title="Go to Profile"><i className="zmdi zmdi-account" /></a></li>
          <li><a href="javascript:void(0);" className="js-right-sidebar" data-close="true"><i className="zmdi zmdi-settings" /></a></li>
          <li><a href="/user/login/logout" title="Log out"><i className="zmdi zmdi-sign-in" /></a></li>
        </ul>
      </div>
      <div className="quick-stats">
        <h5>Today Report</h5>
        <ul>
          <li><span>0<i>Prescription</i></span></li>
          <li><span>0<i>Test</i></span></li>
          <li><span>0<i>Doctor</i></span></li>
        </ul>
      </div>
    </div>
    {/* #User Info */}
    {/* Menu */}
    <div className="menu">
      <ul className="list">
        <li className="header">MAIN NAVIGATION</li>
        <li className="M-main">
          <a href="/user/main">
            <img src="/front-assets/images/dashboard.png" style={{width: 18, height: 18}} />
            <span>Dashboard</span>
          </a>
        </li>
        <li className="M-prescription">
          <a href="javascript:void(0);" className="menu-toggle">
            <img src="/front-assets/images/rx.png" style={{width: 18, height: 18}} /><span>Prescription</span>
          </a>
          <ul className="ml-menu">
            <li className="S-add"><a href="/user/prescription/add">New Prescription</a></li>
            <li className="S-index"><a href="/user/prescription/index">Prescriptions</a></li>
          </ul>
        </li>
        <li className="M-report">
          <a href="javascript:void(0);" className="menu-toggle">
            <img src="/front-assets/images/test.png" style={{width: 18, height: 18}} />
            <span>Test</span>
          </a>
          <ul className="ml-menu">
            <li className="S-add"><a href="/user/report/add">New Test</a></li>
            <li className="S-index"><a href="/user/report/index">Tests</a></li>
          </ul>
        </li>
        <li className="M-doctor">
          <a href="javascript:void(0);" className="menu-toggle">
            <img src="/front-assets/images/doctor.png" style={{width: 18, height: 18}} /><span>Doctor</span>
          </a>
          <ul className="ml-menu">
            <li className="S-add"><a href="/user/doctor/add">New Doctor</a></li>
            <li className="S-index"><a href="/user/doctor/index">Doctors</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </aside>
</section>

      </div>
    )
  }
}
