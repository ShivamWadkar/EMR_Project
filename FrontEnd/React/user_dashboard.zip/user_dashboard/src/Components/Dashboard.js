import React, { Component } from 'react'

export default class 
 extends Component {
  render() {
    return (
      <div>
          <section className="content home">
  <div className="container-fluid">
    <div className="block-header">
      <h2 >Dashboard</h2>
      <small className="text-muted">Welcome to eHealthBook</small>
    </div>
    <div className="row clearfix">
     
      <div className="col-lg-4 col-md-4 col-sm-6">
        <div className="info-box-4 hover-zoom-effect">
          <div className="icon" style={{top: '8px!important'}}>
            <img src="/front-assets/images/rx.png" style={{width: 60, height: 60}} alt="icon" />
          </div>
          <div className="content">
            <div className="text">Prescriptions</div>
            <div className="number">1</div>
          </div>
        </div>
      </div>
      <div className="col-lg-4 col-md-4 col-sm-6">
        <div className="info-box-4 hover-zoom-effect">
          <div className="icon" style={{top: '8px!important'}}>
            <img src="/front-assets/images/test.png" style={{width: 60, height: 60}} alt="icon" />
          </div>
          <div className="content">
            <div className="text">Tests</div>
            <div className="number">0</div>
          </div>
        </div>
      </div>
      <div className="col-lg-4 col-md-4 col-sm-6">
        <div className="info-box-4 hover-zoom-effect">
          <div className="icon" style={{top: '8px!important'}}>
            <img src="/front-assets/images/doctor.png" style={{width: 60, height: 60}} alt="icon" />
          </div>
          <div className="content">
            <div className="text">Doctors</div>
            <div className="number">1</div>
          </div>
        </div>
      </div>
      
    </div>
    <div className="row clearfix">
      <div className="col-lg-6 col-md-6 col-sm-6">
        <div className="card">
          <div className="header">
            <h2>Recent Prescriptions</h2>
            <ul className="header-dropdown">
              <li className="dropdown"> <a href="javascript:void(0);" className="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i className="zmdi zmdi-more-vert" /></a>
                <ul className="dropdown-menu float-right">
                  <li><a href="/user/prescription/index" className=" waves-effect waves-block">View All</a></li>
                </ul>
              </li>
            </ul>
          </div>
          <div className="body">
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Doctor</th>
                    <th>Title</th>
                    <th>Info</th>
                    <th>Date Time</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Datatray Chavan</td>
                    <td>Fever</td>
                    <td />
                    <td>16-01-2022 19:26</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div className="col-lg-6 col-md-6 col-sm-6">
        <div className="card">
          <div className="header">
            <h2>Recent Tests</h2>
            <ul className="header-dropdown">
              <li className="dropdown"> <a href="javascript:void(0);" className="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i className="zmdi zmdi-more-vert" /></a>
                <ul className="dropdown-menu float-right">
                  <li><a href="/user/report/index" className=" waves-effect waves-block">View All</a></li>
                </ul>
              </li>
            </ul>
          </div>
          <div className="body">
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Test</th>
                    <th>Laboratory</th>
                    <th>Date Time</th>
                    {/*<th>Summary</th>*/}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td colSpan={4} className="font-italic text-center">Sorry No Tests Added.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="row clearfix">
      <div className="col-lg-6 col-md-6 col-sm-6">
        <div className="card">
          <div className="header">
            <h2>Recent Doctors</h2>
            <ul className="header-dropdown">
              <li className="dropdown"> <a href="javascript:void(0);" className="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i className="zmdi zmdi-more-vert" /></a>
                <ul className="dropdown-menu float-right">
                  <li><a href="https://mapmyhealth.in/user/doctor/index" className=" waves-effect waves-block">View All</a></li>
                </ul>
              </li>
            </ul>
          </div>
          <div className="body">
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Hospital</th>
                    <th>Specialist</th>
                    <th>Date Time</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Datatray Chavan</td>
                    <td>abc</td>
                    <td>BHMS</td>
                    <td>16-01-2022 18:42</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<div className="color-bg" />

      </div>
    )
  }
}
