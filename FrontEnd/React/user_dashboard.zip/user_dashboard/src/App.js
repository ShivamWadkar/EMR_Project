import logo from './logo.svg';
import './App.css';
import TopBar from './Components/TopBar';
import MenuBar from './Components/MenuBar';
import Dashboard from './Components/Dashboard';

function App() {
  return (
    <div className="App">
      <TopBar/>
      <MenuBar/>
      <Dashboard/>
    </div>
  );
}

export default App;
